create definer = root@localhost view contactclient as
select `databasecourse`.`clientcard`.`idClientCard` AS `idClientCard`,
       `databasecourse`.`clientcard`.`Number`       AS `Number`,
       `databasecourse`.`clientcard`.`FirstName`    AS `FirstName`,
       `databasecourse`.`clientcard`.`SecondName`   AS `SecondName`,
       `databasecourse`.`clientcard`.`ThirdName`    AS `ThirdName`,
       `databasecourse`.`clientcard`.`Phone`        AS `Phone`
from `databasecourse`.`clientcard`
where `databasecourse`.`clientcard`.`Phone` is not null;

