create definer = root@localhost view oldstaff as
select `databasecourse`.`staff`.`idStaff`             AS `idStaff`,
       `databasecourse`.`staff`.`FirstName`           AS `FirstName`,
       `databasecourse`.`staff`.`SecondName`          AS `SecondName`,
       `databasecourse`.`staff`.`ThirdName`           AS `ThirdName`,
       `databasecourse`.`staff`.`PasNumber`           AS `PasNumber`,
       `databasecourse`.`staff`.`BirthDate`           AS `BirthDate`,
       `databasecourse`.`staff`.`Experience`          AS `Experience`,
       `databasecourse`.`staff`.`Position_idPosition` AS `Position_idPosition`
from `databasecourse`.`staff`
where timestampdiff(YEAR, `databasecourse`.`staff`.`BirthDate`, curdate()) >= 40;

