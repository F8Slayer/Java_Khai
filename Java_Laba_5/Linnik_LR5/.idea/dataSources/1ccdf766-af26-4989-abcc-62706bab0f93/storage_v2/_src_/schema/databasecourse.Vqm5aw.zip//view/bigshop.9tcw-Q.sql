create definer = root@localhost view bigshop as
select `databasecourse`.`tradearea`.`idTradeArea`    AS `idTradeArea`,
       `databasecourse`.`tradearea`.`Name`           AS `Name`,
       `databasecourse`.`tradearea`.`Hall`           AS `Hall`,
       `databasecourse`.`tradearea`.`TypeOfPoint_id` AS `TypeOfPoint_id`,
       `databasecourse`.`tradearea`.`Staff_id`       AS `Staff_id`
from `databasecourse`.`tradearea`
where `databasecourse`.`tradearea`.`Hall` >= 3;

