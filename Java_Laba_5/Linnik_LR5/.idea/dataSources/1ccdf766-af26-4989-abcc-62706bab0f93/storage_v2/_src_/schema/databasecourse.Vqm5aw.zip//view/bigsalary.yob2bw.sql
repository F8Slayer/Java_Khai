create definer = root@localhost view bigsalary as
select `databasecourse`.`position`.`idPosition` AS `idPosition`,
       `databasecourse`.`position`.`Name`       AS `Name`,
       `databasecourse`.`position`.`Salary`     AS `Salary`
from `databasecourse`.`position`
where `databasecourse`.`position`.`Salary` > 6000;

